const swotStatements = {
  "Strengths": [
    "Standardized Pricing: Prices are set by the head office in Canada, which ensures consistency and professionalism.",
    "Product Stability: The formula of the product has not changed since 2013, showing strong product reliability and trustworthiness.",
    "Health-Focused: The product is well-aligned with increasing public awareness of health and wellness.",
    "Global Supply Chain: Partnership with an international head office (Canada) adds credibility and stability to operations.",
    "Proven Demand: The pandemic showed a clear spike in product demand, indicating the product’s relevance during health crises."
  ],
  "Weaknesses": [
    "Dependency on International Supply: Shortages can occur due to global events (e.g., pandemics), which heavily affect supply and logistics.",
    "Limited Control Over Pricing: Because the price is dictated by the head office, local sellers have limited flexibility.",
    "Courier Cost Sensitivity: Increases in courier/handling fees directly affect product pricing."
  ],
  "Opportunities": [
    "Rising Health Awareness: More people are now focused on wellness, nutrition, and supplements.",
    "Market Expansion: Can introduce King Herval to new local markets or regions in the Philippines.",
    "Digital Marketing and E-commerce: Leverage online platforms to reach more customers and educate them on the benefits of the supplement.",
    "Partnerships with Health Professionals: Collaborating with wellness coaches, fitness centers, and doctors can boost credibility and sales."
  ],
  "Threats": [
    "Economic Changes: Inflation or rising shipping costs can affect profit margins.",
    "Competition: Increasing number of food supplement brands in the market could attract potential customers away.",
    "Regulatory Risks: Changes in government regulations or health certifications may affect product importation and distribution.",
    "Supply Chain Disruptions: Any issue with the international courier service or head office operations could halt distribution."
  ]
};

const swotFullText = `
<h2>King Herval SWOT Analysis</h2>
<h3>Strengths</h3>
<ul>
  <li>✅ Standardized Pricing: Prices are set by the head office in Canada, which ensures consistency and professionalism.</li>
  <li>✅ Product Stability: The formula of the product has not changed since 2013, showing strong product reliability and trustworthiness.</li>
  <li>✅ Health-Focused: The product is well-aligned with increasing public awareness of health and wellness.</li>
  <li>✅ Global Supply Chain: Partnership with an international head office (Canada) adds credibility and stability to operations.</li>
  <li>✅ Proven Demand: The pandemic showed a clear spike in product demand, indicating the product’s relevance during health crises.</li>
</ul>
<h3>Weaknesses</h3>
<ul>
  <li>⚠️ Dependency on International Supply: Shortages can occur due to global events (e.g., pandemics), which heavily affect supply and logistics.</li>
  <li>⚠️ Limited Control Over Pricing: Because the price is dictated by the head office, local sellers have limited flexibility.</li>
  <li>⚠️ Courier Cost Sensitivity: Increases in courier/handling fees directly affect product pricing.</li>
</ul>
<h3>Opportunities</h3>
<ul>
  <li>🌱 Rising Health Awareness: More people are now focused on wellness, nutrition, and supplements.</li>
  <li>🌍 Market Expansion: Can introduce King Herval to new local markets or regions in the Philippines.</li>
  <li>💼 Digital Marketing and E-commerce: Leverage online platforms to reach more customers and educate them on the benefits of the supplement.</li>
  <li>🤝 Partnerships with Health Professionals: Collaborating with wellness coaches, fitness centers, and doctors can boost credibility and sales.</li>
</ul>
<h3>Threats</h3>
<ul>
  <li>⚠️ Economic Changes: Inflation or rising shipping costs can affect profit margins.</li>
  <li>⚠️ Competition: Increasing number of food supplement brands in the market could attract potential customers away.</li>
  <li>⚠️ Regulatory Risks: Changes in government regulations or health certifications may affect product importation and distribution.</li>
  <li>⚠️ Supply Chain Disruptions: Any issue with the international courier service or head office operations could halt distribution.</li>
</ul>
<div class="credit-container">
  <button id="see-members-button">See the Members</button>
  <p class="credit">Maker: Junald Antoy<br>Partner: Pauline Eson</p>
</div>
`;

let allQuestions = [];
for (const category in swotStatements) {
  swotStatements[category].forEach(statement => {
    allQuestions.push({ statement: statement, answer: category });
  });
}

let currentQuestion = null;
let score = 0;
let questionCount = allQuestions.length;
let questionsAsked = 0;
let attemptsLeft = 3;
let currentQuestionNumber = 0;
let canProceed = false;

const statementElement = document.getElementById('statement');
const optionsContainer = document.getElementById('options');
const feedbackElement = document.getElementById('feedback');
const nextButton = document.getElementById('next-button');
const resultsContainer = document.getElementById('results-container');
const finalScoreElement = document.getElementById('final-score');
const restartButton = document.getElementById('restart-button');
const questionNumberElement = document.getElementById('question-number');
const scoreDisplayElement = document.getElementById('current-score-display');
const completeButton = document.getElementById('complete-button');
completeButton.style.display = 'none';
const introContainer = document.getElementById('intro-container');
const startButton = document.getElementById('start-button');
const questionContainer = document.getElementById('question-container');

const gameContainer = document.getElementById('game-container');
gameContainer.insertBefore(questionNumberElement, questionContainer);
gameContainer.insertBefore(scoreDisplayElement, questionContainer);
gameContainer.appendChild(completeButton);

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function loadQuestion() {
  if (questionsAsked >= questionCount) {
    statementElement.textContent = '';
    optionsContainer.style.display = 'none';
    feedbackElement.textContent = `You have answered all ${questionCount} questions!`;
    feedbackElement.className = 'correct';
    nextButton.style.display = 'none';
    completeButton.style.display = 'block';
    canProceed = false;
    return;
  }

  currentQuestionNumber++;
  questionNumberElement.textContent = `Question ${currentQuestionNumber}/${questionCount}`;
  scoreDisplayElement.textContent = `Score: ${score}`;

  feedbackElement.textContent = '';
  feedbackElement.className = '';
  nextButton.style.display = 'none';
  optionsContainer.style.display = 'grid';
  optionsContainer.querySelectorAll('.option-button').forEach(button => {
    button.disabled = false;
  });

  currentQuestion = allQuestions[questionsAsked];
  attemptsLeft = 3;
  canProceed = false;

  if (currentQuestion) {
    statementElement.textContent = currentQuestion.statement;
  } else {
    statementElement.textContent = 'Error: No more questions.';
    optionsContainer.style.display = 'none';
  }
}

function checkAnswer(selectedAnswer) {
  optionsContainer.querySelectorAll('.option-button').forEach(button => {
    button.disabled = true;
  });

  if (selectedAnswer === currentQuestion.answer) {
    feedbackElement.textContent = 'Correct!';
    feedbackElement.className = 'correct';
    score++;
    scoreDisplayElement.textContent = `Score: ${score}`;
    questionsAsked++;
    canProceed = true;
    if (questionsAsked < questionCount) {
      setTimeout(loadQuestion, 1500);
    } else {
      statementElement.textContent = '';
      optionsContainer.style.display = 'none';
      feedbackElement.textContent = `You have answered all ${questionCount} questions correctly!`;
      nextButton.style.display = 'none';
      completeButton.style.display = 'block';
    }
  } else {
    attemptsLeft--;
    feedbackElement.textContent = `Incorrect. You have ${attemptsLeft} attempts left.`;
    feedbackElement.className = 'incorrect';
    if (attemptsLeft > 0) {
      optionsContainer.querySelectorAll('.option-button').forEach(button => {
        button.disabled = false;
      });
    } else {
      feedbackElement.textContent = `Out of attempts! The correct answer was ${currentQuestion.answer}. Starting over.`;
      feedbackElement.className = 'incorrect';
      currentQuestionNumber = 0;
      score = 0;
      scoreDisplayElement.textContent = `Score: ${score}`;
      questionsAsked = 0;
      setTimeout(startGame, 2000);
    }
  }
}

function showResults() {
  const resultsContainer = document.getElementById('results-container');
  resultsContainer.innerHTML = swotFullText;
  const playAgainButton = document.createElement('button');
  playAgainButton.id = 'restart-button-final';
  playAgainButton.textContent = 'Play Again';
  resultsContainer.appendChild(playAgainButton);
  playAgainButton.addEventListener('click', startGame);

  const seeMembersButton = document.getElementById('see-members-button');
  const creditContainer = resultsContainer.querySelector('.credit-container');
  const creditText = resultsContainer.querySelector('.credit');

  if (seeMembersButton && creditText && creditContainer) {
    seeMembersButton.addEventListener('click', () => {
      creditText.style.display = creditText.style.display === 'none' ? 'block' : 'none';
    });
    creditText.style.display = 'none'; // Initially hide the credit text
  }
}

function startGame() {
  currentQuestionNumber = 0;
  score = 0;
  scoreDisplayElement.textContent = `Score: ${score}`;
  questionsAsked = 0;
  shuffleArray(allQuestions);
  resultsContainer.style.display = 'none';
  questionContainer.style.display = 'none';
  optionsContainer.style.display = 'none';
  completeButton.style.display = 'none';
  introContainer.style.display = 'block';
}

function proceedToGame() {
  introContainer.style.display = 'none';
  questionContainer.style.display = 'block';
  optionsContainer.style.display = 'grid';
  loadQuestion();
}

document.addEventListener('DOMContentLoaded', () => {
  startGame();

  optionsContainer.addEventListener('click', (event) => {
    if (event.target.classList.contains('option-button') && attemptsLeft > 0 && !event.target.disabled) {
      checkAnswer(event.target.dataset.type);
    }
  });

  nextButton.addEventListener('click', loadQuestion);

  completeButton.addEventListener('click', () => {
    questionContainer.style.display = 'none';
    resultsContainer.style.display = 'block';
    showResults();
  });

  const initialRestartButton = document.getElementById('restart-button');
  initialRestartButton.addEventListener('click', startGame);

  startButton.addEventListener('click', proceedToGame);
});